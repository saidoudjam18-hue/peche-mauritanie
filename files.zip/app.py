from flask import Flask, render_template, request, jsonify
from datetime import datetime
import json, os

app = Flask(__name__)

# Stockage simple dans un fichier JSON (pas besoin de base de données)
RESERVATIONS_FILE = "reservations.json"

def load_reservations():
    if os.path.exists(RESERVATIONS_FILE):
        with open(RESERVATIONS_FILE, "r") as f:
            return json.load(f)
    return []

def save_reservation(data):
    reservations = load_reservations()
    data["date"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    data["id"] = len(reservations) + 1
    reservations.append(data)
    with open(RESERVATIONS_FILE, "w") as f:
        json.dump(reservations, f, ensure_ascii=False, indent=2)
    return data

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/reserver", methods=["POST"])
def reserver():
    data = request.get_json()
    nom      = data.get("nom", "").strip()
    telephone = data.get("telephone", "").strip()
    type_peche = data.get("type_peche", "")
    message  = data.get("message", "").strip()

    if not nom or not telephone:
        return jsonify({"success": False, "erreur": "Nom et téléphone requis"}), 400

    reservation = save_reservation({
        "nom": nom,
        "telephone": telephone,
        "type_peche": type_peche,
        "message": message
    })

    return jsonify({
        "success": True,
        "message": f"Merci {nom} ! Nous vous contacterons bientôt.",
        "id": reservation["id"]
    })

@app.route("/api/reservations")
def liste_reservations():
    """Route admin pour voir toutes les réservations"""
    return jsonify(load_reservations())

# ─── Lancement ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
